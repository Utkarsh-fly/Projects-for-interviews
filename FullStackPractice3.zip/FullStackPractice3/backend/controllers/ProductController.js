//19
import { connection } from "../connection/dbconnection.js";
//12
export const insertProduct = ((req, res) => {

    //13
    const { pid } = req.params;
    const { pname, qty, price, mfgdate } = req.body;

    //14
    const sql = "insert into myProduct12(pname,qty,price,mfgdate) value (?,?,?,?)";

    //15
    connection.query(sql, [pname, qty, price, mfgdate], (error, result) => {

        if (error) {
            res.status(500).json({ message: "insert product failed" });
        }

        res.json({ message: "insert product done", data: result });
    })

})

export const getAllProduct = ((req, res) => {

    //13
    // const{pid,pname,qty,price,mfgdate} = req.body;

    //14
    const sql = "select * from myProduct12";

    //15
    connection.query(sql, (error, result) => {

        if (error) {
            res.status(500).json({ message: "show product failed" });
        }

        res.json({ message: "show product done", data: result });
    })

})


// export const getProductById=((req,res)=>{

//     //13
//     const{pid} = req.params;

//     //14
//     const sql ="select * from myProduct12 where pid =?";

//     //15
//     connection.query(sql,[pid],(error,result)=>{

//         if(error)
//         {
//             res.status(500).json({message:"show product failed"});
//         }

//         res.json({message:"show product done", data:result[0] });
//     })

// })

// export const updateProduct=((req,res)=>{

//     //13
//     const{pid} = req.params;
//     const{pname,qty,price,mfgdate} = req.body;

//     //14
//     const sql ="update myProduct12 set pname=?, qty=?,price=?, mfgdate=? where pid=?";

//     //15
//     connection.query(sql,[pname,qty,price,mfgdate,pid],(error,result)=>{

//         if(error)
//         {
//             res.status(500).json({message:"update product failed"});
//         }

//         res.json({message:"update product done", data:result });
//     })

// })

export const deleteProduct = ((req, res) => {

    //13
    const { pid } = req.params;

    //14
    const sql = "delete from myProduct12 where pid=?";

    //15
    connection.query(sql, [pid], (error, result) => {

        if (error) {
            res.status(500).json({ message: "delete product failed" });
        }

        res.json({ message: "delete product done", data: result });
    })

})

export const getProductById = ((req, res) => {

    //13
    // const{pid,pname,qty,price,mfgdate} = req.body;
    const { pid } = req.params;

    //14
    const sql = "select * from myProduct12 where pid=?";

    //15
    connection.query(sql, [pid], (error, result) => {

        if (error) {
            res.status(500).json({ message: "show product failed" });
        }

        res.json({ message: "show product done", data: result[0] });
    })

})

export const updateProduct = ((req, res) => {

    //13
    const { pid } = req.params;
    const { pname, qty, price, mfgdate } = req.body;


    //14
    const sql = "update myProduct12 set pname=?, qty=?, price=?, mfgdate=? where pid=?";

    //15
    connection.query(sql, [pname, qty, price, mfgdate, pid], (error, result) => {

        if (error) {
            res.status(500).json({ message: "show u product failed" });
        }

        res.json({ message: "show u product done", data: result });
    })

})