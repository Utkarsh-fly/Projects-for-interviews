//1 import express
import express from "express"

//5) import cors
import cors from "cors";

//21 import produ
import ProductRouters from "./routers/ProductRouters.js"

//2 var
const app = express();

//3 use
app.use(express.json());

//7
app.use(cors())
//5
// app.use("/",(req,res)=>{
//     res.send("working")
// })

//8 router call
app.use("/product",ProductRouters);


//4 listen
app.listen(3000,()=>{
    console.log("expresss is running in 3000");
    
})