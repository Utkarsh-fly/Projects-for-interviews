//import router
import { Router } from "express";

//20
import { insertProduct,getAllProduct, getProductById, updateProduct ,deleteProduct} from "../controllers/ProductController.js";
//10
const router = Router();

//11
router.post("/products",insertProduct);
router.get("/products",getAllProduct);
router.get("/products/:pid",getProductById);
router.put("/products/:pid",updateProduct);
router.delete("/products/:pid",deleteProduct);



export default router;