//16 
import mysql from "mysql2";

//17
export const connection = mysql.createConnection({

    host:"localhost",
    user:"root",
    password:"US@sahu1",
    database:"expressDB",
})

connection.connect((error)=>{
    if(error)
    {
        console.log("db connection failed");
        
    }
    else
    {
        console.log("db connection success");
        
    }
})