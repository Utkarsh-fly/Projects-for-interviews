//4
import axios from 'axios'
//5
import { useState, useEffect } from 'react'
import { addproduct, deleteProduct, getAllProduct, getProductById, updateProduct } from './ProductService';



function App() {
  // 8
  const [form, setForm] = useState({

    pid: "", pname: "", qty: "", price: "", mfgdate: ""
  })

  const [products, setProducts] = useState([]);
  // const [pid, setPid] = useState("");

  const [pid,setPid] = useState("")
  //10 handler

  const handleInput = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  const handleAdd = async (e) => {

    e.preventDefault();

    //check pname should not be empty
    if (!form.pname || (form.price<=0)|| !/^[A-Za-z0-9]+$/.test(form.pname) ) {
      alert("form need pname");
      return;
    }

    const res = await addproduct(form);

    setProducts(res.data.data);



    setForm({ pid: "", pname: "", qty: "", price: "", mfgdate: "" })

    loadProducts();

  }

  // const handleSearch = async () => {
  //   const res = await getProductById(pid);
  //   setProducts([res.data.data]);


  //   setPid("")

  // }

  // const handleUpdate = async (e) => {
  //   e.preventDefault();

  //       //check pname should not be empty
  //   if (!form.pname) {
  //     alert("form need pname");
  //     return;
  //   }


  //   const res = await updateProduct(form.pid, form);
  //   setProducts([res.data.data]);


  //   loadProducts();

  // }

    const handleUpdate = async (e)=>{

    e.preventDefault();
   const a= await updateProduct(form.pid,form);
   setProducts([a.data.data]);

   loadProducts();

  }

  //search
  const handleSearch= async()=>{
    const res =await getProductById(pid);
    setProducts([res.data.data]);

    setPid("");
  }

  

  const handleDelete = async (pid) => {

    const res = await deleteProduct(pid);


    loadProducts();

  }



  const loadProducts = async () => {

    const res = await getAllProduct();
    setProducts(res.data.data);

  }

  useEffect(() => {
    loadProducts();
  }, []);

  //6 form
  return (
    <>
      {/* 7 */}
      <form onSubmit={handleAdd}>

        {/* <input name='' value={pid} placeholder='search pid' onChange={(e) => setPid(e.target.value)} />
        <button type='button' onClick={handleSearch}>search</button> */}


        <input name="pid" value={form.pid} onChange={handleInput} placeholder='pid' />
        <input name="pname" value={form.pname} onChange={handleInput} placeholder='pname' />
        <input name="qty" value={form.qty} onChange={handleInput} placeholder='qty' />
        <input name="price" value={form.price} onChange={handleInput} placeholder='price' />
        <input name="mfgdate" value={form.mfgdate} onChange={handleInput} placeholder='mfgdate' />

        <button type='submit'>add</button>
      </form>

      {/* 9 */}
      <ul>
        {
          products.map((p) => (

            <li key={p.pid}>
              {p.pid}-{p.pname}-{p.qty}-{p.price}-{p.mfgdate}
            </li>
          ))
        }
      </ul>


 

       
      <h1>update product</h1>

      <form onSubmit={handleUpdate}>

        <input name="" value={pid}  onChange={(e)=>setPid(e.target.value)} placeholder='search' />
        <button type='button' onClick={handleSearch}>search</button>

        <input name="pid" value={form.pid} onChange={handleInput} placeholder='pid' />

        <input name="pname" value={form.pname} onChange={handleInput} placeholder='pname' />
        <input name="qty" value={form.qty} onChange={handleInput} placeholder='qty' />
        <input name="price" value={form.price} onChange={handleInput} placeholder='price' />
        <input name="mfgdate" value={form.mfgdate} onChange={handleInput} placeholder='mfgdate' />

        <button type='submit' >update</button>
      </form> 

      {/* 9 */}
      <ul>
        {
          products.map((p) => (

            <li key={p.pid}>
              {p.pid}-{p.pname}-{p.qty}-{p.price}-{p.mfgdate}
              <button type='button' onClick={() => handleDelete(p.pid)}>delete</button>

            </li>
          ))
        }
      </ul> 



      
    </>
  )
}

export default App
