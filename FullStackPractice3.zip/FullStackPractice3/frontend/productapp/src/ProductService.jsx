//1 import axios
import axios from "axios";

//2
const api = "http://localhost:3000/product/products";

//3 
export const addproduct=(product)=>{
    
    return axios.post(api,product);
}

export const getAllProduct=()=>{
    
    return axios.get(api);
}

export const getProductById=(pid)=>{
    
    return axios.get(`${api}/${pid}`);
}

export const updateProduct=(pid,product)=>{
    
    return axios.put(`${api}/${pid}`,product);
}

export const deleteProduct=(pid)=>{
    
    return axios.delete(`${api}/${pid}`);
}