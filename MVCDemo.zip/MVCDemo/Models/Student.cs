﻿using System.ComponentModel.DataAnnotations;

namespace MVCDemo.Models
{
    public class Student
    {
        [Required(ErrorMessage = "Address is required")]
        public int No { get; set; }

        [Required(ErrorMessage = "Name is required")]

        public String Name { get; set; }

        [Required(ErrorMessage = "Address is required")]

        public String Address { get; set; }

        [Required(ErrorMessage = "Email is required")]

        public String Email { get; set; }

        [Required(ErrorMessage = "Age is required")]
        [Range(20,40, ErrorMessage = "Age value is incorrect!")]

        public int Age { get; set; }


        public bool IsEmailValidated { get; set; }





    }
}
