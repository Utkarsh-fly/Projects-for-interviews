﻿using System.ComponentModel.DataAnnotations; // we get require range, regular expr

//this is server side validateion
namespace MVCDemo.Models
{
    public class LoginUser
    {

        [Required(ErrorMessage = "User Name Can't be Empty!")]
        public String UserName { get; set; }

        [Required(ErrorMessage = "Password Can't be Empty!")]

        public String Password { get; set; }

    }
}
