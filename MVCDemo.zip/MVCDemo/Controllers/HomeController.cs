﻿using Microsoft.AspNetCore.Mvc;
using MVCDemo.Filters;
using MVCDemo.Models;

namespace MVCDemo.Controllers
{
    [LogFilter]
    public class HomeController : Controller
    {
        StudentViewModel svm = new StudentViewModel();

        [AuthFilter]
        public IActionResult Index()
        {
            ViewBag.Title = "Home";
            ViewBag.UserName = GetUserName();

            List<Student> students = svm.GetStudents();
            return View(students);
        }



        [AuthFilter]
        public IActionResult Create()
        {
            return View();
        }

        [AuthFilter]
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if(ModelState.IsValid)
            {
                svm.AddStudent(student);
                return Redirect("/Home/Index");
            }
            else
            {
                ViewBag.Message = "something is not right with data";
                return View(student);
            }
        }






        [AuthFilter]
        public IActionResult Edit(int id)
        {
            Student student = svm.GetStudent(id);
            return View(student);
        }

        [AuthFilter]
        [HttpPost]
        public IActionResult Edit(Student updatedstudent)
        {
            if (ModelState.IsValid)
            {
               int rowsAffected = svm.UpdateStudent(updatedstudent);

                if(rowsAffected>0)
                {
                    return Redirect("/Home/Index");

                }
                else
                {
                    ViewBag.Message = "Failed to updated Record";
                    return View(updatedstudent);
                }
            }
            else
            {
                ViewBag.Message = "something is not right with data";
                return View(updatedstudent);
            }
        }












        public IActionResult About()
        {
            ViewBag.Title = "About US";
            ViewBag.UserName = GetUserName();

            return View();
        }

        public IActionResult Contact()
        {
            ViewBag.Title = "Contact Us";
            ViewBag.UserName = GetUserName();

            return View();
        }

        private string GetUserName()
        {
            if(HttpContext.Session.GetString("UserName")!=null && 
                HttpContext.Session.GetString("UserName")!=" ")
            {
                return HttpContext.Session.GetString("UserName");
            }
            else
            {
                return "Guest";
            }
        }


        [AuthFilter]
        public IActionResult Delete(int id)
        {
           svm.RemoveStudent(id);
            return Redirect("/Home/Index");
        }
    }
}
